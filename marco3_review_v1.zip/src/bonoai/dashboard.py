"""Dashboard MVP for backtest results (read-only)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    import streamlit as st  # type: ignore[import-not-found]
else:
    try:
        import streamlit as st  # type: ignore[import-not-found]
    except ImportError:
        st = None  # type: ignore[assignment]


def load_run_data(run_dir: Path) -> dict[str, Any] | None:
    """Load backtest run from separate config and metrics files."""
    config_file = run_dir / "config.json"
    metrics_file = run_dir / "metrics.json"
    manifest_file = run_dir / "manifest.json"

    if not config_file.exists() or not metrics_file.exists():
        return None

    try:
        with open(config_file) as f:
            config = cast(dict[str, Any], json.load(f))
        with open(metrics_file) as f:
            metrics = cast(dict[str, Any], json.load(f))
        with open(manifest_file) as f:
            manifest = cast(dict[str, Any], json.load(f))

        return {
            "config": config,
            "metrics": metrics,
            "status": manifest.get("status", "unknown"),
            "run_id": manifest.get("run_id", ""),
        }
    except Exception:
        return None


def main(artifacts_dir: str = "backtests/runs") -> None:
    """Dashboard main entry point."""
    if st is None:
        raise ImportError("Streamlit required for dashboard; install with: pip install streamlit")

    st.set_page_config(page_title="BonoAI Backtest Dashboard", layout="wide")
    st.title("🎰 BonoAI Backtest Results")
    st.markdown("Walk-forward validation without temporal leakage")

    artifacts_path = Path(artifacts_dir)
    if not artifacts_path.exists():
        st.warning("No backtests found")
        return

    runs = sorted(artifacts_path.glob("*/manifest.json"))
    if not runs:
        st.warning("No backtest runs available")
        return

    run_ids = [r.parent.name for r in runs]
    selected_run = st.selectbox("Select Run", run_ids, key="run_select")

    if selected_run:
        run_dir = artifacts_path / selected_run
        data = load_run_data(run_dir)

        if data:
            col1, col2, col3 = st.columns(3)

            with col1:
                st.metric("Strategy", data["config"]["strategy_name"])
            with col2:
                status_label = "✅ Success" if data["status"] == "success" else "❌ Failed"
                st.metric("Status", status_label)
            with col3:
                if "metrics" in data:
                    st.metric("Avg Hits", f"{data['metrics']['average_hits']:.2f}")

            st.divider()

            if "metrics" in data:
                metrics = data["metrics"]

                col1, col2, col3, col4 = st.columns(4)
                with col1:
                    st.metric("Hit Rate (2+)", f"{metrics['hit_rate_2_plus']:.1%}")
                with col2:
                    st.metric("Hit Rate (3+)", f"{metrics['hit_rate_3_plus']:.1%}")
                with col3:
                    st.metric("Hit Rate (4+)", f"{metrics['hit_rate_4_plus']:.1%}")
                with col4:
                    st.metric("Hit Rate (6)", f"{metrics['hit_rate_6']:.1%}")

                st.divider()
                st.subheader("Distribution")

                if metrics["hit_distribution"]:
                    import pandas as pd  # type: ignore[import-untyped]

                    dist_df = pd.DataFrame(
                        list(metrics["hit_distribution"].items()),
                        columns=["Hits", "Count"]
                    )
                    st.bar_chart(dist_df.set_index("Hits"))

            st.divider()
            st.subheader("Configuration")
            config = data["config"]
            st.json({
                "period": f"{config['start_date']} → {config['end_date']}",
                "training_window_days": config["training_window_days"],
                "random_seed": config["random_seed"],
            })

        else:
            st.error(f"Failed to load {run_dir}")


if __name__ == "__main__":
    main()
