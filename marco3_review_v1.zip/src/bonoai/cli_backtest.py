"""Backtest CLI commands for walk-forward validation."""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path

from bonoai.application.baseline_strategies import BASELINE_STRATEGIES
from bonoai.application.walk_forward import WalkForwardValidator
from bonoai.domain.backtesting import BacktestConfig, BacktestRun
from bonoai.infrastructure.backtest_artifacts import AtomicArtifactWriter
from bonoai.infrastructure.csv_repository import CsvDrawRepository


def _canonical_repository(data_dir: Path) -> CsvDrawRepository:
    return CsvDrawRepository(data_dir / "processed" / "draws.csv")


def run_backtest_command(args: argparse.Namespace) -> int:
    """Execute backtest subcommands."""
    if args.backtest_command == "run":
        return _run_backtest_run(args)
    if args.backtest_command == "list":
        return _run_backtest_list(args)
    if args.backtest_command == "show":
        return _run_backtest_show(args)
    if args.backtest_command == "compare":
        return _run_backtest_compare(args)
    if args.backtest_command == "verify":
        return _run_backtest_verify(args)
    return 2


def _run_backtest_run(args: argparse.Namespace) -> int:
    """Execute walk-forward validation."""
    repository = _canonical_repository(args.data_dir)
    records = tuple(repository.list_all())

    if not records:
        import sys
        print("ERROR: base canônica vazia", file=sys.stderr)
        return 2

    try:
        config = BacktestConfig(
            strategy_name=args.strategy,
            start_date=args.start_date,
            end_date=args.end_date,
            training_window_days=args.training_window,
            tickets_per_draw=10,
            random_seed=args.seed,
            dataset_sha256="0" * 64,
            code_commit_sha="0" * 64,
        )
    except ValueError as e:
        import sys
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    run_id = BacktestConfig.canonical_run_id(config)

    validator = WalkForwardValidator(records)
    strategy_fn = BASELINE_STRATEGIES[args.strategy]

    try:
        metrics = validator.execute(config, strategy_fn)
        run = BacktestRun(
            run_id=run_id,
            config=config,
            started_at_utc=datetime.now(UTC),
            completed_at_utc=datetime.now(UTC),
            status="success",
            metrics=metrics,
        )

        writer = AtomicArtifactWriter(args.artifacts_dir)
        run_file, sha = writer.write_run_record(run)

        if args.as_json:
            output = {"run_id": run_id, "status": "success", "file": str(run_file), "sha256": sha}
            print(json.dumps(output, ensure_ascii=False, indent=2))
            return 0

        print(f"Backtest: {run.config.strategy_name}")
        print(f"Período: {run.config.start_date} → {run.config.end_date}")
        if run.metrics:
            print(f"Média de acertos: {run.metrics.average_hits:.2f}")
            print(f"Taxa 2+: {run.metrics.hit_rate_2_plus:.1%}")
            print(f"Taxa 6: {run.metrics.hit_rate_6:.1%}")
        print(f"Salvo em: {run_file}")
        return 0

    except Exception as e:
        import sys
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


def _run_backtest_list(args: argparse.Namespace) -> int:
    """List all backtest runs."""
    if not args.artifacts_dir.exists():
        print("Nenhuma execução encontrada")
        return 0

    runs = sorted(args.artifacts_dir.glob("*/manifest.json"))
    print(f"Execuções: {len(runs)}")
    for manifest_file in runs[:10]:
        run_id = manifest_file.parent.name
        print(f"  {run_id}")
    if args.as_json:
        data = {"count": len(runs), "runs": [r.parent.name for r in runs[:10]]}
        print(json.dumps(data, ensure_ascii=False, indent=2))
    return 0


def _run_backtest_show(args: argparse.Namespace) -> int:
    """Show detailed backtest results."""
    import sys
    run_dir = args.artifacts_dir / args.run_id
    config_file = run_dir / "config.json"
    metrics_file = run_dir / "metrics.json"

    if not config_file.exists():
        print(f"ERROR: {config_file} não encontrado", file=sys.stderr)
        return 2

    try:
        with open(config_file) as f:
            config = json.load(f)
        with open(metrics_file) as f:
            metrics = json.load(f)

        if args.as_json:
            output = {"run_id": args.run_id, "config": config, "metrics": metrics}
            print(json.dumps(output, ensure_ascii=False, indent=2))
        else:
            print(f"Run ID: {args.run_id}")
            print(f"Estratégia: {config['strategy_name']}")
            if metrics and "average_hits" in metrics:
                print(f"Média: {metrics['average_hits']:.2f}")
        return 0
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


def _run_backtest_compare(args: argparse.Namespace) -> int:
    """Compare two backtest runs."""
    import sys
    metrics1_file = args.artifacts_dir / args.run_id_1 / "metrics.json"
    metrics2_file = args.artifacts_dir / args.run_id_2 / "metrics.json"

    if not metrics1_file.exists():
        print(f"ERROR: {metrics1_file} não encontrado", file=sys.stderr)
        return 2
    if not metrics2_file.exists():
        print(f"ERROR: {metrics2_file} não encontrado", file=sys.stderr)
        return 2

    try:
        with open(metrics1_file) as f:
            m1 = json.load(f)
        with open(metrics2_file) as f:
            m2 = json.load(f)

        if args.as_json:
            comparison = {
                "run_1": args.run_id_1,
                "run_2": args.run_id_2,
                "avg_diff": (m2.get("average_hits", 0)
                            - m1.get("average_hits", 0)),
            }
            print(json.dumps(comparison, ensure_ascii=False, indent=2))
        else:
            print(f"Comparação: {args.run_id_1[:8]} vs {args.run_id_2[:8]}")
            diff = m2.get("average_hits", 0) - m1.get("average_hits", 0)
            print(f"Diferença média: {diff:+.2f}")
        return 0
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2


def _run_backtest_verify(args: argparse.Namespace) -> int:
    """Verify backtest integrity and artifact SHA-256."""
    import hashlib
    import sys
    run_dir = args.artifacts_dir / args.run_id
    manifest_file = run_dir / "manifest.json"

    if not manifest_file.exists():
        print(f"ERROR: {manifest_file} não encontrado", file=sys.stderr)
        return 2

    try:
        with open(manifest_file) as f:
            manifest = json.load(f)

        files_to_check = list(manifest.get("files", {}).keys())
        all_valid = True
        failed_files = []

        for fname in files_to_check:
            fpath = run_dir / fname
            if not fpath.exists():
                all_valid = False
                failed_files.append(f"{fname} (não existe)")
                continue

            with open(fpath, "rb") as f:
                actual_hash = hashlib.sha256(f.read()).hexdigest()
            expected_hash = manifest["files"][fname]

            if actual_hash != expected_hash:
                all_valid = False
                failed_files.append(f"{fname} (hash divergente)")

        if args.as_json:
            print(json.dumps({
                "run_id": args.run_id,
                "valid": all_valid,
                "files_checked": len(files_to_check),
                "failed": failed_files,
            }, ensure_ascii=False, indent=2))
        else:
            print(f"Verificação: {args.run_id[:8]}")
            print(f"Status: {'✓ válido' if all_valid else '✗ inválido'}")
            print(f"Arquivos: {len(files_to_check)} verificados")
            if failed_files:
                for fail in failed_files:
                    print(f"  ✗ {fail}")
        return 0 if all_valid else 1
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2
